# LaserTRACER and Coordinate Measuring Machine comparison - "LaserTRACER" Folder



This project was developed at Aix Marseille University, CNRS, ISM, Marseille, France.

This repository contains the implementation of a multilateration algorithm for LaserTRACER data. It is based on the least-squares method applied to object measurements performed in the laboratory. It is designed to be used with [MATLAB (R2024b)](https://fr.mathworks.com/products/matlab.html).

This Matlab module was created by Noah BERTIN.



## Requisites

&#x20;   Matlab (Version R2024b recommended)



## General instructions

The Trac-CAL v2.1 data is stored in .tcd format (the software's native format), but can also be imported and read directly in Excel.

The MATLAB folder contains post-processed .csv files for Initial Conditions (Targets - Stations) and measurements, alongside all the scripts required for the computation:

* main.m: The primary execution script.
* montecarlo.m: Adds noise to the measurement values using the Monte Carlo method.
* reconstruction.m: Reconstructs the coordinate (Targets - Stations) and deadzone matrices from the optimization vector.
* residual\_computation.m: Defines and computes the problem's residual.

Results are stored in .csv format.

