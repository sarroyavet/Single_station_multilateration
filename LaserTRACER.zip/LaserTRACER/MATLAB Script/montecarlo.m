function mesures_mc = montecarlo(mesures_init)
    [nl, nc] = size(mesures_init);
    rnd = rand(nl, nc);
        
    et_sys = 0.0002 + 0.0003 .* mesures_init*(10^-3);


    a = mesures_init - 2.*et_sys/sqrt(3); % Remplacer et/sqrt(4) par et du résidu 1/ddl*resnorm
    b = mesures_init + 2.*et_sys/sqrt(3);

    mesures_mc = a + (b-a).*rnd;
end