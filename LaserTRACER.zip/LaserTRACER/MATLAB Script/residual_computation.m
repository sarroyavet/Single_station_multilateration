function [err, dist_calc, points_calc, laser_calc, deadzone_calc] = residual_computation(x, dist_mes, n_laser, mult_dz)

[points_calc, laser_calc, deadzone_calc] = reconstruct(x, n_laser,mult_dz);

dist_calc = pdist2(laser_calc,points_calc);

err = zeros(n_laser*5, 8);
if mult_dz == 1
    for laser = 1:n_laser
        for points = 1:8
            err(laser,points) = dist_mes(laser,points) - (deadzone_calc(laser) + dist_calc(laser,points)); 
            err(laser+6,points) = dist_mes(laser+6,points) - (deadzone_calc(laser) + dist_calc(laser,points));
            err(laser+12,points) = dist_mes(laser+12,points) - (deadzone_calc(laser) + dist_calc(laser,points));
            err(laser+18,points) = dist_mes(laser+18,points) - (deadzone_calc(laser) + dist_calc(laser,points));
            err(laser+24,points) = dist_mes(laser+24,points) - (deadzone_calc(laser) + dist_calc(laser,points));
        end
    end
elseif mult_dz == 2
    for laser = 1:n_laser
        for points = 1:8
            err(laser,points) = dist_mes(laser,points) - (deadzone_calc + dist_calc(laser,points)); 
            err(laser+6,points) = dist_mes(laser+6,points) - (deadzone_calc + dist_calc(laser,points));
            err(laser+12,points) = dist_mes(laser+12,points) - (deadzone_calc + dist_calc(laser,points));
            err(laser+18,points) = dist_mes(laser+18,points) - (deadzone_calc + dist_calc(laser,points));
            err(laser+24,points) = dist_mes(laser+24,points) - (deadzone_calc + dist_calc(laser,points));
        end
    end
end

end