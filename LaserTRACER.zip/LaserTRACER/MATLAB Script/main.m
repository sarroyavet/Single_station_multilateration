clear all

results_path = '../MATLAB Results';

% Number of Monte-Carlo iterations
it_mc = 30000;

% Data importation
meas_LT1 = table2array(readtable("Data_LT1.csv"))'; % LT measurements : Technique LT mobile, objet fixe
coord_LT1 = table2array(readtable("IC_LT1.csv")); % Initialization for stations coordinates

meas_LT2 = table2array(readtable("Data_LT2.csv"))'; % LT measurements : Technique LT fixe, objet mobile
coord_LT2 = table2array(readtable("IC_LT2.csv")); % Initialization for stations coordinates

coord_target = table2array(readtable("IC_Target.csv")); % Initialization for targets coordinates

%% lsqnonlin options
options = optimoptions('lsqnonlin', 'MaxIterations', 10000, ...     % Maximum number of iterations allowed
    'MaxFunctionEvaluations', 50000, ...                            % Maximum number of objective function evaluations
    'FunctionTolerance', 1e-10, ...                                 % Termination tolerance on the function value change
    'StepTolerance', 1e-10, ...                                     % Termination tolerance on the step size
    'OptimalityTolerance', 1e-10, ...                               % Tolerance on the first-order optimality condition
    'Display', 'iter');                                             % Display progress at each iteration    

%% Technique : Multiple LT stations, fixed 3D structure

% Deadzones initialization
dz_LT1 = zeros(1, 6); % 6 deadzones because of the initialization of LT

% Distances storage initialization
dist_storage_LT1 = zeros(28, it_mc);

% Optimization vector initialization
x0_t1 = [coord_target(:); coord_LT1(:); dz_LT1(:)]; % Targets coordinates, Stations coordinates, Deadzones

% Loop for each iteration
for i=1:it_mc

    meas_MC_LT1 = montecarlo(meas_LT1); % Noisy distances

    fun = @(x) residual_computation(x, meas_MC_LT1, 6, 1);
    
    % Algorithm limits for optimization vector
    lb_LT1 = x0_t1 - 10000;
    ub_LT1 = x0_t1 + 10000;
    
    % Multilateration computation
    [x_opt_t1, resnorm_t1] = lsqnonlin(fun, x0_t1, lb_LT1, ub_LT1, options);
    
    % Final solution reconstruction
    [P_final_t1, N_final_t1, deadzone_final_t1] = reconstruct(x_opt_t1, 6, 1);

    % Distances between each target
    dist_laser_t1 = pdist(P_final_t1);
    dist_storage_LT1(:,i) = dist_laser_t1(:);
    
end


%% Technique : Single LT station, moving 3D structure

% Deadzones initialization
dz_LT2 = zeros(1, 1); % 1 deadzones thanks to the target park

% Distances storage initialization
dist_storage_LT2 = zeros(28, it_mc);

% Optimization vector initialization
x0_t2 = [coord_target(:); coord_LT2(:); dz_LT2(:)]; % Targets coordinates, Stations coordinates, Deadzones

% Loop for each iteration
for i=1:it_mc

    meas_MC_LT2 = montecarlo(meas_LT2); % Noisy distances

    fun = @(x) residual_computation(x, meas_MC_LT2, 6, 2);
    
    % Algorithm limits for optimization vector
    lb_LT2 = x0_t2 - 10000;
    ub_LT2 = x0_t2 + 10000;
    
    % Multilateration computation
    [x_opt_t2, resnorm_t2] = lsqnonlin(fun, x0_t2, lb_LT2, ub_LT2, options);
    
    % Final solution reconstruction
    [P_final_t2, N_final_t2, deadzone_final_t2] = reconstruct(x_opt_t2, 6, 2);

    % Distances between each target
    dist_laser_t2 = pdist(P_final_t2);
    dist_storage_LT2(:,i) = dist_laser_t2(:);
    
end

%% Results exportation

% Mean of distances obtained via Monte-Carlo
dist_LT1 = mean(dist_storage_LT1,2);
dist_LT2 = mean(dist_storage_LT2,2);

% Uncertainty based on : Repositionning error, Target Center error and LaserTRACER error obtained via Monte-Carlo
U_dist_LT1 = sqrt(2*(0.004/(2*sqrt(3)))^2 + (0.0016/(2*sqrt(3)))^2+std(dist_storage_LT1, [], 2).^2)*2;
U_dist_LT2 = sqrt(2*(0.004/(2*sqrt(3)))^2 + (0.0016/(2*sqrt(3)))^2+std(dist_storage_LT2, [], 2).^2)*2;

% Export results on .csv files
dist_LT1_path = fullfile(results_path, 'Dist_LT1.csv');
writematrix(dist_LT1, dist_LT1_path);

u_t1_path = fullfile(results_path, 'U_LT1.csv');
writematrix(U_dist_LT1, u_t1_path);

dist_LT2_path = fullfile(results_path, 'Dist_LT2.csv');
writematrix(dist_LT2, dist_LT2_path);

u_t2_path = fullfile(results_path, 'U_LT2.csv');
writematrix(U_dist_LT2, u_t2_path);