function [P_calc, N_calc, deadzone] = reconstruct(x, n_laser, mult_dz)

P_calc = reshape(x(1:24), [8,3]);

N_calc = reshape(x(25:(24+n_laser*3)), [n_laser,3]);

if mult_dz == 1
    deadzone = x(25+n_laser*3:end);
elseif mult_dz == 2
    deadzone = x(end);
end

end