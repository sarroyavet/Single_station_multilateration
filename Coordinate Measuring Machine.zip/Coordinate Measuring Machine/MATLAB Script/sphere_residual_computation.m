function err = sphere_residual_computation(x, P_sphere, n_point)

% Residual storage creation
err = zeros(n_point, 1);

% Loop for each point of the sphere
for i = 1:n_point
    % Residual : difference between radius and distance Sphere Center - Point
    err(i) = x(4) - sqrt((x(1)-P_sphere(i,1))^2 + (x(2)-P_sphere(i,2))^2 + (x(3)-P_sphere(i,3))^2);
end

end