clear all

results_path = '../MATLAB Results';

% lsqnonlin options
options = optimoptions('lsqnonlin', 'MaxIterations', 10000, ...     % Maximum number of iterations allowed
    'MaxFunctionEvaluations', 50000, ...                            % Maximum number of objective function evaluations
    'FunctionTolerance', 1e-10, ...                                 % Termination tolerance on the function value change
    'StepTolerance', 1e-10, ...                                     % Termination tolerance on the step size
    'OptimalityTolerance', 1e-10, ...                               % Tolerance on the first-order optimality condition
    'Display', 'iter');                                             % Display progress at each iteration                                       

% Storage initialisation
x_opt_tot = zeros(8, 4); % Optimization vector
resnorm_tot = zeros(8, 1); % Residual for analystic propagation
J_tot = cell(8, 1); % Jacobian matrix
uX_target_tot = cell(8,1); % Coordinates uncertainty

% Loop for each point
for i = 1:8
    file_name = "Target_" + i + ".csv";
    target_coords = table2array(readtable(file_name)); % Points from measure
    n_point = size(target_coords,1); % Number of points
    
    % Optimization vector
    x0_target = [target_coords(1,1), target_coords(1,2), target_coords(1,3), 19.05]; % Sphere center coordinates and radius

    fun = @(x) sphere_residual_computation(x, target_coords, n_point);
    
    % Computation
    [x_opt, resnorm, ~, ~, ~, ~, J] = lsqnonlin(fun, x0_target, [], [], options);

    % Residual variance
    var_ei = resnorm / (n_point - 4);

    % Optimization vector variance diagonal
    uX = sqrt(diag((full(J)'*full(J))^(-1)*var_ei));
    
    % Results storage
    x_opt_tot(i,:) = x_opt;
    resnorm_tot(i) = resnorm;
    J_tot{i} = J;
    uX_target_tot{i} = uX;
end

% Distances between each points
coord_sphere = x_opt_tot(:, 1:3);
dist_cmm = pdist(coord_sphere);


%% Uncertainty propagation
it = 1; % Iteration to store uncertainty

% Storage initialisation for distance uncertainty
U_dist_cmm = zeros(28,1);

% Loop for every distance between each point
for Pi = 1:7 % Points 1 to 7
    for Pj = (Pi+1):8 % Points from Pi + 1 to 8

        % Y = sqrt((x1-x2)^2 + ... + (z1-z2)^2)
        % Propagation : u = J(Y)*Var(XiXj)*J(Y)^t

        denom = dist_cmm(it); % Denominator from the derivative of Y : same for all the derivatives
        
        % Terms of propagation formula
        term1 = (coord_sphere(Pi,1)-coord_sphere(Pj,1))/denom * uX_target_tot{Pi}(1);
        term2 = (coord_sphere(Pi,2)-coord_sphere(Pj,2))/denom * uX_target_tot{Pi}(2);
        term3 = (coord_sphere(Pi,3)-coord_sphere(Pj,3))/denom * uX_target_tot{Pi}(3);

        term4 = -(coord_sphere(Pi,1)-coord_sphere(Pj,1))/denom * uX_target_tot{Pj}(1);
        term5 = -(coord_sphere(Pi,2)-coord_sphere(Pj,2))/denom * uX_target_tot{Pj}(2);
        term6 = -(coord_sphere(Pi,3)-coord_sphere(Pj,3))/denom * uX_target_tot{Pj}(3);

        % Uncertainty based on : Repositionning error and CMM error obtained via uncertainty propagation
        U_dist_cmm(it) = 2*sqrt(2*(0.004/(2*sqrt(3)))^2 + (term1^2 + term2^2 + term3^2 + term4^2 + term5^2 + term6^2));
        
        it = it+1;
    end
end

% Export results on .csv files
dist_path = fullfile(results_path, 'Dist_CMM.csv');
writematrix(dist_cmm, dist_path);

u_path = fullfile(results_path, 'U_CMM.csv');
writematrix(U_dist_cmm, u_path);
