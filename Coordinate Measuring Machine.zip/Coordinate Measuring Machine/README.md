# LaserTRACER and Coordinate Measuring Machine comparison - "Coordinate Measuring Machine" Folder



This project was developed at Aix Marseille University, CNRS, ISM, Marseille, France.

This repository contains the implementation of a sphere reconstruction algorithm for Coordinate Measuring Machine (CMM) data. It is based on the least-squares method applied to object measurements performed in the laboratory. It is designed to be used with [MATLAB (R2024b)](https://fr.mathworks.com/products/matlab.html).

This Matlab module was created by Noah BERTIN.



## Requisites

&#x20;   Matlab (Version R2024b recommended)



## General instructions

The M-COSMOS v5 data is stored as extensionless files, but they can still be imported and read directly in Excel.

The MATLAB Script folder contains post-processed .csv files for measurements, alongside all the scripts required for the computation:

* main.m: The primary execution script.
* sphere\_residual\_computation.m: Defines and computes the problem's residual.

Results are stored in .csv format.



